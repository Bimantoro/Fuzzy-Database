<?php 

	$t = max(3,4,null);
	echo $t;
	echo "<br>";

	$l = min(5, 1, 2, 3, 4);
	echo $l;

 ?>