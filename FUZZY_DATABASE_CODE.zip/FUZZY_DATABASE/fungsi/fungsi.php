<?php 
	function konek_db(){
		mysql_connect('localhost','root','');
		mysql_select_db('car_db');
	}

	function mf_linear_naik($nilai, $pilihan, $status){
		//fungsi aktivasi linear naik
		$query = mysql_query("SELECT * FROM ".$pilihan." WHERE status='".$status."';");
		$data = mysql_fetch_array($query);
		$batas_bawah = $data['batas_bawah'];
		$batas_atas = $data['batas_atas'];


		//fungsi keanggotaan linear naik 

		if($nilai<=$batas_bawah){
			$nk = 0;
		}else if($nilai>=$batas_atas){
			$nk = 1;
		}else{
			$nk = ($nilai - $batas_bawah)/($batas_atas - $batas_bawah);
		}
		
		return $nk;
	}

	function mf_linear_turun($nilai, $pilihan, $status){
		//fungsi aktivasi linear turun
		//$sql = "SELECT * FROM ".$pilihan." WHERE status_jenis"
		$query = mysql_query("SELECT * FROM ".$pilihan." WHERE status='".$status."';");
		$data = mysql_fetch_array($query);
		$batas_bawah = $data['batas_bawah'];
		$batas_atas = $data['batas_atas'];

		//fungsi keanggotaan linear turun

		if($nilai<=$batas_bawah){
			$nk = 1;
		}else if($nilai>=$batas_atas){
			$nk = 0;
		}else{
			$nk = ($batas_atas - $nilai)/($batas_atas - $batas_bawah);
		}
		
		return $nk;
	}

	function mf_linear_sgt($nilai, $pilihan, $status){
		//fungsi aktivasi linear segitiga
		$query = mysql_query("SELECT * FROM ".$pilihan." WHERE status='".$status."';");
		$data = mysql_fetch_array($query);
		$batas_bawah = $data['batas_bawah'];
		$batas_tengah = $data['batas_tengah'];
		$batas_atas = $data['batas_atas'];


		//fungsi keanggotaan segitiga :
		if($nilai<=$batas_bawah || $nilai>=$batas_atas){
			$nk = 0;
		}else if($batas_bawah<=$nilai && $nilai<=$batas_tengah){
			$nk = ($nilai - $batas_bawah)/($batas_tengah - $batas_bawah);
		}else{
			$nk = ($batas_atas - $nilai)/($batas_atas - $batas_tengah);
		}

		return $nk;
	}

	function lihat_hasil($engine, $harga, $jenis, $kapasitas, $bbm, $operator){
		$sql = mysql_query("SELECT * FROM d_car");

		if($engine!='' && $harga!='' && $jenis!='' && $kapasitas!='' && $bbm!='' && $operator){
			while($data = mysql_fetch_array($sql)){
				$t_engine	= 'f_engine';
				$t_harga	= 'f_harga';
				$t_jenis	= 'f_jenis';
				$t_kapasitas	= 'f_kapasitas';
				$t_bbm		= 'f_bbm';

				$i = 0;
				$temp;

				$max = 0;
				$min = 5;

				//cek engine
				if($engine=='-'){
					$nk_engine	= '-';
				}else if($engine=='kecil'){
					$nk_engine	= mf_linear_turun($data['kapasitas_engine'], $t_engine, $engine);

					$temp[$i]	= $nk_engine;
					$i++;

				}else{
					$nk_engine	= mf_linear_naik($data['kapasitas_engine'], $t_engine, $engine);

					$temp[$i]	= $nk_engine;
					$i++;
				}


				//cek harga
				if($harga=='-'){
					$nk_harga	= '-';
				}else if($harga=='murah'){
					$nk_harga	= mf_linear_turun($data['harga'], $t_harga, $harga);

					$temp[$i]	= $nk_harga;
					$i++;

				}else if($harga=='sedang'){
					$nk_harga	= mf_linear_sgt($data['harga'], $t_harga, $harga);

					$temp[$i]	= $nk_harga;
					$i++;

				}else{
					$nk_harga	= mf_linear_naik($data['harga'], $t_harga, $harga);

					$temp[$i]	= $nk_harga;
					$i++;

				}
				
				//cek jenis kendaraan
				if($jenis=='-'){
					$nk_jenis	='-';
				}
				if($jenis=='antik'){
					$nk_jenis	= mf_linear_turun($data['tahun'], $t_jenis, $jenis);

					$temp[$i]	= $nk_jenis;
					$i++;

				}else{
					$nk_jenis	= mf_linear_naik($data['tahun'], $t_jenis, $jenis);

					$temp[$i]	= $nk_jenis;
					$i++;

				}

				//cek konsumsi bahan bakar
				if($bbm=='-'){
					$nk_bbm		='-';
				}else if($bbm=='boros'){
					$nk_bbm		= mf_linear_turun($data['jarak_tempuh'], $t_bbm, $bbm);

					$temp[$i]	= $nk_bbm;
					$i++;

				}else if($bbm=='sedang'){
					$nk_bbm		= mf_linear_sgt($data['jarak_tempuh'], $t_bbm, $bbm);

					$temp[$i]	= $nk_bbm;
					$i++;

				}else{
					$nk_bbm		= mf_linear_naik($data['jarak_tempuh'], $t_bbm, $bbm);

					$temp[$i]	= $nk_bbm;
					$i++;

				}


				//cek kapasitas penumpang
				if($kapasitas=='-'){
					$nk_kapasitas	='-';
				}else if($kapasitas=='sedikit'){
					$nk_kapasitas	= mf_linear_turun($data['kapasitas_penumpang'], $t_kapasitas, $kapasitas);

					$temp[$i]	= $nk_kapasitas;
					$i++;

				}else{
					$nk_kapasitas	= mf_linear_naik($data['kapasitas_penumpang'], $t_kapasitas, $kapasitas);

					$temp[$i]	= $nk_kapasitas;
					$i++;

				}


				if($operator=='AND'){
					for($a=0; $a<$i; $a++){
						if($min>=$temp[$a]){
							$min=$temp[$a];
						}
					}
					$kesimpulan = $min;
				}else{
					for($a=0; $a<$i; $a++){
						if($max<=$temp[$a]){
							$max=$temp[$a];
						}
					}
					$kesimpulan = $max;
				}
				
				$hasil[]	= array(	'id'	=> $data['id'],
										'nama'	=> $data['nama'],
										'merek'	=> $data['merek'],
										'harga'	=> $data['harga'],
										'cc'	=> $data['kapasitas_engine'],
										'kp'	=> $data['kapasitas_penumpang'],
										'bbm'	=> $data['jarak_tempuh'],
										'tahun'	=> $data['tahun'],
										'nk_engine'	=> round($nk_engine,2),
										'nk_harga'	=> round($nk_harga,2),
										'nk_jenis'	=> round($nk_jenis,2),
										'nk_bbm'	=> round($nk_bbm,2),
										'nk_kapasitas'	=> round($nk_kapasitas,2),
										'ks'	=> round($kesimpulan,2));
			}

			return $hasil;
		}
		
	}

	function rp($angka)
	{
		if($angka==null){
			$jadi = "Rp. -";
		}else{
			 $jadi = "Rp " . number_format($angka,2,',','.');
		}
	
	return $jadi;
	}

	function km($angka)
	{
		if($angka==null){
			$jadi = "- km";
		}else{
			 $jadi = $angka." km";
		}
	
	return $jadi;
	}

	function cc($angka)
	{
	 $jadi = $angka." cc";
	return $jadi;
	}

	function org($angka)
	{
	 $jadi = $angka." orang";
	return $jadi;
	}


 ?>