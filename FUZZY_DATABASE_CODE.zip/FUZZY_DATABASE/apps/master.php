<?php 
	require_once('../fungsi/fungsi.php');
	konek_db();

 ?>


 <!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Sistem Pendukung Keputusan Pemilihan Kendaraan</title>

<link href="../css/bootstrap.min.css" rel="stylesheet">
<link href="../css/datepicker3.css" rel="stylesheet">
<link href="../css/styles.css" rel="stylesheet">

<!--Icons-->
<script src="js/lumino.glyphs.js"></script>

<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->

</head>

<body style="background: url('asset/background2.jpg') repeat;">
	<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
		<div class="container-fluid">
			<div class="navbar-header">
				<a class="navbar-brand" href="index.php"><span style="color: white;"><b>Fuzzy Cari Kendaraan | </b></span></a> <a href="master.php" class="navbar-brand" style="color: red;">Master Data</a>
			</div>
							
		</div><!-- /.container-fluid -->
	</nav>
		
	<div class="col-md-8 col-md-offset-2">			
		
		

		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					
				</div>
			</div>
		</div><!--/.row-->


		<div class="row" >
			<div class="col-md-12">
				<div class="panel panel-default">
					<div>
						<img src="asset/background.jpg" class="img img-responsive">
					</div>
				</div>
				<div class="panel panel-default">
					<div class="panel-heading"><svg class="glyph stroked desktop"><use xlink:href="#stroked-desktop"></use></svg>Edit Master Data :</div>
					<div class="panel-body">
						<form method="post" action="proses.php">
						<div class="row">
							<div class="col-md-4">
								<a href="mobil.php" class="btn btn-default" style="width: 100%;">Kendaraan</a>
								<div align="center">-------------------------------------------</div>
								<a href="harga.php" class="btn btn-default" style="width: 100%;">Harga</a>
								
								
							</div>
							<div class="col-md-4">
								<a href="kapasitas.php" class="btn btn-default" style="width: 100%;">Kapasitas</a>
								<div align="center">-------------------------------------------</div>
								<a href="bbm.php" class="btn btn-default" style="width: 100%;">Konsumsi BBM</a>
								
							</div>

							<div class="col-md-4">
								<a href="engine.php" class="btn btn-default" style="width: 100%;">Engine</a>
								<div align="center">-------------------------------------------</div>
								<a href="jenis.php" class="btn btn-default" style="width: 100%;">Jenis</a>
							</div>
						</div>
						</form>
					</div>
				</div>
				
			</div>		
		</div>
		
								
		</div><!--/.row-->
	</div>	<!--/.main-->

	<script src="../js/jquery-1.11.1.min.js"></script>
	<script src="../js/bootstrap.min.js"></script>
	<script src="../js/chart.min.js"></script>
	<script src="../js/chart-data.js"></script>
	<script src="../js/easypiechart.js"></script>
	<script src="../js/easypiechart-data.js"></script>
	<script src="../js/bootstrap-datepicker.js"></script>
	<script>
		$('#calendar').datepicker({
		});

		!function ($) {
		    $(document).on("click","ul.nav li.parent > a > span.icon", function(){          
		        $(this).find('em:first').toggleClass("glyphicon-minus");      
		    }); 
		    $(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
		}(window.jQuery);

		$(window).on('resize', function () {
		  if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
		})
		$(window).on('resize', function () {
		  if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
		})
	</script>

</body>

</html>