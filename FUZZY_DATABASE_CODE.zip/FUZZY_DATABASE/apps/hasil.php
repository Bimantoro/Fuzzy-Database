<?php 

$data1 = $_POST['0'];
$data2 = $_POST['1'];
$data3 = $_POST['2'];
$data4 = $_POST['3'];


echo $data1;
echo "<br>";

echo $data2;
echo "<br>";

echo $data3;
echo "<br>";

echo $data4;
echo "<br>";

 ?>
