<?php 
	require_once('../fungsi/fungsi.php');
	konek_db();
	$id = $_GET['id'];
	$query = mysql_query("DELETE FROM d_car where id='".$id."'");
	if($query){
		echo "<script>alert('Berhasil dihapus'); </script>";
		echo "<meta http-equiv='refresh' content='0; url=mobil.php'>";
	}else{
		echo "<script>alert('gagal dihapus'); </script>";
		echo "<meta http-equiv='refresh' content='0; url=mobil.php'>";
	}

 ?>