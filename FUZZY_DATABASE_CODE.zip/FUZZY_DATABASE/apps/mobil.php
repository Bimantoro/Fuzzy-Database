<?php 
	$nama_file="nn.jpg";
	$peringatan='';
	require_once('../fungsi/fungsi.php');
	konek_db();

	if(isset($_POST['upload'])){
		$target_dir = "asset/mobil/";
	      $target_file = $target_dir . basename($_FILES["gambar"]["name"]);
	      $uploadOk = 1;
	      $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

	      
	      $check = getimagesize($_FILES["gambar"]["tmp_name"]);
	      if($check !== false) {
	              $uploadOk = 1;
	          } else {
	              $peringatan="maaf yang anda pilih bukan gambar :-(";
	              $uploadOk = 0;
	          }
	      

	      if ($_FILES["gambar"]["size"] > 2000000) {
	          $peringatan='ukuran gambar terlalu besar pilih gambar dengan ukuran kurang 2 MB';
	          $uploadOk = 0;
	      }

	      if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
	      && $imageFileType != "gif" ) {
	          $peringatan='pilih gambar dengan format JPG, PNG, JPEG atau GIF';
	          $uploadOk = 0;
	      }

	      if ($uploadOk == 0) {
	          
	      } else {
	          if (move_uploaded_file($_FILES["gambar"]["tmp_name"], $target_file)) {
	              $nama_file=$_FILES['gambar']['name'];
	          } else {
	              echo "<script>alert('gambar tidak terupload ke server'); </script>";
	              echo "<meta http-equiv='refresh' content='0; url=update_studio.php'>";
	              
	          }
	      }
	}

	if(isset($_POST['simpan'])){
		$nama = $_POST['nama'];
		$merek = $_POST['merek'];
		$gambar = $_POST['path_file'];
		$cc = $_POST['cc'];
		$bbm = $_POST['bbm'];
		$orang = $_POST['orang'];
		$harga = $_POST['harga'];
		$tahun = $_POST['tahun'];

		$query = mysql_query("INSERT INTO d_car VALUES('','".$nama."','".$merek."','".$gambar."','".$harga."','".$cc."','".$orang."','".$bbm."','".$tahun."');");
		if($query){
			echo "<script>alert('data berhasil disimpan !');</script>";
        	echo "<meta http-equiv='refresh' content='0; url=mobil.php'>";
		}else{
			echo "<script>alert('data gagal disimpan !');</script>";
        	echo "<meta http-equiv='refresh' content='0; url=mobil.php'>";
		}
	}



 ?>


 <!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Sistem Pendukung Keputusan Pemilihan Kendaraan</title>

<link href="../css/bootstrap.min.css" rel="stylesheet">
<link href="../css/datepicker3.css" rel="stylesheet">
<link href="../css/styles.css" rel="stylesheet">

<link href="../bower_components/datatables-responsive/css/dataTables.responsive.css" rel="stylesheet">
<link href="../bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.css" rel="stylesheet">

<!--Icons-->
<script src="js/lumino.glyphs.js"></script>

<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->

</head>

<body style="background: url('asset/background2.jpg') repeat;">
	<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
		<div class="container-fluid">
			<div class="navbar-header">
				<a class="navbar-brand" href="index.php"><span style="color: white;"><b>Fuzzy Cari Kendaraan | </b></span></a> <a href="master.php" class="navbar-brand" style="color: red;">Master Data</a>
			</div>
							
		</div><!-- /.container-fluid -->
	</nav>
		
	<div class="col-md-8 col-md-offset-2">			
		
		

		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					
				</div>
			</div>
		</div><!--/.row-->


		<div class="row" >
			<div class="col-md-12">
				<div class="panel panel-default">
					<div>
						<img src="asset/background.jpg" class="img img-responsive">
					</div>
				</div>
				<div class="panel panel-default">
					<div class="panel-heading"><svg class="glyph stroked desktop"><use xlink:href="#stroked-desktop"></use></svg>Update Data Harga Kendaraan:</div>
					<div class="panel-body">
						<form method="post" action="#" enctype="multipart/form-data">
						<div class="col-md-6">
							<div class="form-group">
								<label>Nama Kendaraan :</label>
								<input type="text" name="nama" class="form-control">
							</div>

							<div class="form-group">
								<label>Merek Kendaraan :</label>
								<input type="text" name="merek" class="form-control">
							</div>

							<div class="form-group">
								<label>Gambar :</label>
								<input type="file" name="gambar" class="form-control">
								<br>
								<input type="text" name="path_file" class="form-control" value=<?php echo $nama_file; ?> readonly>
								<br>
								<button type="submit" name="upload" class="btn btn-primary" style="width: 100%;">Upload</button>
							</div>
						</div>

						<div class="col-md-6">
							<div class="form-group">
								<label>Kapasitas Mesin (cc) :</label>
								<input type="number" name="cc" class="form-control">
							</div>

							<div class="form-group">
								<label>Harga Kendaraan (Rp.) :</label>
								<input type="number" name="harga" class="form-control">
							</div>

							<div class="form-group">
								<label>konsumsi Bahan Bakar (/liter) :</label>
								<input type="number" name="bbm" class="form-control">
							</div>

							<div class="form-group">
								<label>Kapasitas Penumpang (orang) :</label>
								<input type="number" name="orang" class="form-control">
							</div>

							<div class="form-group">
								<label>Tahun Produksi:</label>
								<input type="number" name="tahun" class="form-control">
							</div>
						</div>
						
						<div class="form-group">
							<button class="btn btn-danger" style="width: 100%;" name="simpan" >Simpan</button>
						</div>
						</form>
					</div>
				</div>

				<div class="panel panel-default">
					<div class="panel-heading"><svg class="glyph stroked desktop"><use xlink:href="#stroked-desktop"></use></svg>Batas Untuk Harga kendaraan:</div>
					<div class="panel-body">
						<div class="row" style="padding: 20px;">
							 <table class="table table-striped table-bordered table-hover" id="dataTables-example">
								 <tr>
								 	<th data-sortable="true">nama</th>
						        <th data-sortable="true">merek</th>
						        <th data-sortable="true">harga</th>
						        <th data-sortable="true">tahun</th>
						        <th data-sortable="true">bbm</th>
						        <th data-sortable="true">kapasitas</th>
						        <th data-sortable="true">engine</th>
						        <th data-sortable="true">Action</th>
								 </tr>
								<?php 
								$sql = mysql_query("SELECT * FROM d_car;");
								while ($isi = mysql_fetch_array($sql)) {
									?>
									<tr>
										<td><?php echo $isi['nama']; ?></td>
										<td><?php echo $isi['merek']; ?></td>
										<td><?php echo rp($isi['harga']); ?></td>	
										<td><?php echo $isi['tahun']; ?></td>					
										<td><?php echo km($isi['jarak_tempuh']); ?></td>										
										<td><?php echo org($isi['kapasitas_penumpang']); ?></td>
										<td><?php echo cc($isi['kapasitas_engine']); ?></td>
										<td><a href="delete_car.php?id=<?php echo $isi['id']; ?>" class="btn btn-danger" style="width: 100%;">hapus</a></td>
									</tr>
									<?php
								}

							 ?>

							 </table>
							
						</div>
					</div>
				</div>
				
			</div>		
		</div>
		
								
		</div><!--/.row-->
	</div>	<!--/.main-->

	<script src="../js/jquery-1.11.1.min.js"></script>
	<script src="../js/bootstrap.min.js"></script>
	<script src="../js/chart.min.js"></script>
	<script src="../js/chart-data.js"></script>
	<script src="../js/easypiechart.js"></script>
	<script src="../js/easypiechart-data.js"></script>
	<script src="../js/bootstrap-datepicker.js"></script>

	<script src="../bower_components/datatables/media/js/jquery.dataTables.min.js"></script>
    <script src="../bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js"></script>

    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
               "language": {
            "lengthMenu": "Menampilkan _MENU_ baris tiap halaman",
            "zeroRecords": "Maaf, Data tidak ditemukan !",
            "info": "Halaman _PAGE_ dari _PAGES_",
            "infoEmpty": "Tidak ada data tersedia",
            "infoFiltered": "(difilter dari _MAX_ total data)"
        }

        });
    });
    </script>

	<script>
		$('#calendar').datepicker({
		});

		!function ($) {
		    $(document).on("click","ul.nav li.parent > a > span.icon", function(){          
		        $(this).find('em:first').toggleClass("glyphicon-minus");      
		    }); 
		    $(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
		}(window.jQuery);

		$(window).on('resize', function () {
		  if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
		})
		$(window).on('resize', function () {
		  if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
		})
	</script>

</body>

</html>