<?php 
	require_once('../fungsi/fungsi.php');
	konek_db();

	if(isset($_POST['simpan'])){
		$sedikit_bawah = $_POST['0'];
		$sedikit_atas = $_POST['1'];
		$banyak_bawah = $_POST['2'];
		$banyak_atas = $_POST['3'];

		$sedikit = mysql_query("UPDATE f_engine SET batas_bawah='".$sedikit_bawah."', batas_atas='".$sedikit_atas."' WHERE status='kecil';");
		$banyak = mysql_query("UPDATE f_engine SET batas_bawah='".$banyak_bawah."', batas_atas='".$banyak_atas."' WHERE status='besar';");

	}



 ?>


 <!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Sistem Pendukung Keputusan Pemilihan Kendaraan</title>

<link href="../css/bootstrap.min.css" rel="stylesheet">
<link href="../css/datepicker3.css" rel="stylesheet">
<link href="../css/styles.css" rel="stylesheet">

<!--Icons-->
<script src="js/lumino.glyphs.js"></script>

<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->

</head>

<body style="background: url('asset/background2.jpg') repeat;">
	<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
		<div class="container-fluid">
			<div class="navbar-header">
				<a class="navbar-brand" href="index.php"><span style="color: white;"><b>Fuzzy Cari Kendaraan | </b></span></a> <a href="master.php" class="navbar-brand" style="color: red;">Master Data</a>
			</div>
							
		</div><!-- /.container-fluid -->
	</nav>
		
	<div class="col-md-8 col-md-offset-2">			
		
		

		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					
				</div>
			</div>
		</div><!--/.row-->


		<div class="row" >
			<div class="col-md-12">
				<div class="panel panel-default">
					<div>
						<img src="asset/background.jpg" class="img img-responsive">
					</div>
				</div>
				<div class="panel panel-default">
					<div class="panel-heading"><svg class="glyph stroked desktop"><use xlink:href="#stroked-desktop"></use></svg>Update Data Kapasitas Mesin Kendaraan :</div>
					<div class="panel-body">
						<form method="post" action="#">
						<div class="row">
							<?php 
								$query = mysql_query("SELECT * FROM f_engine;");
								$i=0;
								while ($data = mysql_fetch_array($query)) {

							 ?>
							<div class="col-md-6">
								<div class="form-group">
									<label align="center"><?php echo $data['status']; ?> :</label>
									<hr>
									<p>Batas Bawah  :</p>
									<input type="text" class="form-control" name=<?php echo $i; ?> value=<?php echo $data['batas_bawah']; ?>>
									<?php $i++; ?>
									<hr>
									<p>Batas Atas  :</p>
									<input type="text" class="form-control" name= <?php echo $i; ?> value=<?php echo $data['batas_atas']; ?>>
									<?php $i++; ?>
									
								</div>							
							</div>
							<?php } ?>
						</div>
						<div class="form-group">
							<button class="btn btn-danger" style="width: 100%;" name="simpan" >Simpan</button>
						</div>
						</form>
					</div>
				</div>

				<div class="panel panel-default">
					<div class="panel-heading"><svg class="glyph stroked desktop"><use xlink:href="#stroked-desktop"></use></svg>Batas Untuk Kapasitas Mesin Kendaraan :</div>
					<div class="panel-body">
						<div class="row" style="padding: 20px;">
							 <table class="table table-bordered">
								 <tr>
								 	<th>Status</th>
								 	<th>Batas Bawah</th>
								 	<th>Batas Atas</th>
								 </tr>
								<?php 
								$sql = mysql_query("SELECT * FROM f_engine;");
								while ($isi = mysql_fetch_array($sql)) {
									?>
									<tr>
										<td><?php echo $isi['status']; ?></td>
										<td><?php echo cc($isi['batas_bawah']); ?></td>
										<td><?php echo cc($isi['batas_atas']); ?></td>
									</tr>
									<?php
								}

							 ?>

							 </table>
							
						</div>
					</div>
				</div>
				
			</div>		
		</div>
		
								
		</div><!--/.row-->
	</div>	<!--/.main-->

	<script src="../js/jquery-1.11.1.min.js"></script>
	<script src="../js/bootstrap.min.js"></script>
	<script src="../js/chart.min.js"></script>
	<script src="../js/chart-data.js"></script>
	<script src="../js/easypiechart.js"></script>
	<script src="../js/easypiechart-data.js"></script>
	<script src="../js/bootstrap-datepicker.js"></script>
	<script>
		$('#calendar').datepicker({
		});

		!function ($) {
		    $(document).on("click","ul.nav li.parent > a > span.icon", function(){          
		        $(this).find('em:first').toggleClass("glyphicon-minus");      
		    }); 
		    $(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
		}(window.jQuery);

		$(window).on('resize', function () {
		  if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
		})
		$(window).on('resize', function () {
		  if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
		})
	</script>

</body>

</html>