<?php 

	require_once('../fungsi/fungsi.php');
	konek_db();

	$id = $_GET['id'];
	$query = mysql_query("SELECT * FROM d_car WHERE id='".$id."'");
	$data = mysql_fetch_array($query);


 ?>

 <!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Sistem Pendukung Keputusan Pemilihan Kendaraan</title>

<link href="../css/bootstrap.min.css" rel="stylesheet">
<link href="../css/datepicker3.css" rel="stylesheet">
<link href="../css/styles.css" rel="stylesheet">

<link href="../bower_components/datatables-responsive/css/dataTables.responsive.css" rel="stylesheet">
<link href="../bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.css" rel="stylesheet">

<!--Icons-->
<script src="js/lumino.glyphs.js"></script>

<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->

</head>

<body style="background: url('asset/background2.jpg') repeat;">
	<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
		<div class="container-fluid">
			<div class="navbar-header">
				<a class="navbar-brand" href="index.php"><span style="color: white;"><b>Fuzzy Cari Kendaraan | </b></span></a> <a href="master.php" class="navbar-brand" style="color: red;">Master Data</a>
			</div>
							
		</div><!-- /.container-fluid -->
	</nav>
		
	<div class="col-md-8 col-md-offset-2">			
		
		

		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					
				</div>
			</div>
		</div><!--/.row-->


		<div class="row" >
			<div class="col-md-12">
				<div class="panel panel-default">
					<div style="padding: 25px;">
						<p align="center"><img src="asset/mobil/<?php echo $data['gambar']; ?>" class="img img-responsive"></p>
						
					</div>
				</div>
				<div class="panel panel-default">
					<div class="panel-heading"><svg class="glyph stroked desktop"><use xlink:href="#stroked-desktop"></use></svg>Detail Kendaraan:</div>
					<div class="panel-body">
						<div class="col-md-6">
							<table class="table table-bordered">
								<tr>
									<td><b>nama 	:</b></td>
									<td><?php echo $data['nama']; ?></td>									
								</tr>

								<tr>
									<td><b>merek 	:</b></td>
									<td><?php echo $data['merek']; ?></td>									
								</tr>

								<tr>
									<td><b>Kapasitas Mesin 	:</b></td>
									<td><?php echo cc($data['kapasitas_engine']); ?></td>									
								</tr>
							</table>

						</div>

						<div class="col-md-6">
							<table class="table table-bordered">
								<tr>
									<td><b>Harga 	:</b></td>
									<td><?php echo rp($data['harga']); ?></td>									
								</tr>

								<tr>
									<td><b>Konsumsi BBM 	:</b></td>
									<td><?php echo km($data['jarak_tempuh']); ?></td>									
								</tr>

								<tr>
									<td><b>Kapasitas Penumpang 	:</b></td>
									<td><?php echo org($data['kapasitas_penumpang']);  ?></td>									
								</tr>

								<tr>
									<td><b>Tahun Produksi 	:</b></td>
									<td><?php echo $data['tahun'];  ?></td>									
								</tr>
							</table>
						</div>
						
					</div>
				</div>
				
			</div>		
		</div>
		
								
		</div><!--/.row-->
	</div>	<!--/.main-->

	<script src="../js/jquery-1.11.1.min.js"></script>
	<script src="../js/bootstrap.min.js"></script>
	<script src="../js/chart.min.js"></script>
	<script src="../js/chart-data.js"></script>
	<script src="../js/easypiechart.js"></script>
	<script src="../js/easypiechart-data.js"></script>
	<script src="../js/bootstrap-datepicker.js"></script>

	<script src="../bower_components/datatables/media/js/jquery.dataTables.min.js"></script>
    <script src="../bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js"></script>

    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
               "language": {
            "lengthMenu": "Menampilkan _MENU_ baris tiap halaman",
            "zeroRecords": "Maaf, Data tidak ditemukan !",
            "info": "Halaman _PAGE_ dari _PAGES_",
            "infoEmpty": "Tidak ada data tersedia",
            "infoFiltered": "(difilter dari _MAX_ total data)"
        }

        });
    });
    </script>

	<script>
		$('#calendar').datepicker({
		});

		!function ($) {
		    $(document).on("click","ul.nav li.parent > a > span.icon", function(){          
		        $(this).find('em:first').toggleClass("glyphicon-minus");      
		    }); 
		    $(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
		}(window.jQuery);

		$(window).on('resize', function () {
		  if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
		})
		$(window).on('resize', function () {
		  if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
		})
	</script>

</body>

</html>