<?php 
	require_once('../fungsi/fungsi.php');
	konek_db();
	$engine = $_POST['cc'];
	$jenis  = $_POST['jenis'];
	$harga  = $_POST['harga'];
	$bbm  	= $_POST['bbm'];
	$kapasitas  = $_POST['kapasitas'];	
	$operator = $_POST['operator'];

	$hasil = lihat_hasil($engine, $harga, $jenis, $kapasitas, $bbm, $operator);
	echo $engine;

 ?>


 <!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Layanan SMS Gateway - Pusat Al-Qur'an Terpadu</title>

<link href="../css/bootstrap.min.css" rel="stylesheet">
<link href="../css/datepicker3.css" rel="stylesheet">
<link href=".../css/bootstrap-table.css" rel="stylesheet">
<link href="../css/styles.css" rel="stylesheet">
<link href="../bower_components/datatables-responsive/css/dataTables.responsive.css" rel="stylesheet">
<link href="../bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.css" rel="stylesheet">

<!--Icons-->
<script src="js/lumino.glyphs.js"></script>

<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->

</head>

<body style="background: url('asset/background2.jpg') repeat;">
	<nav class="navbar navbar-inverse navbar-fixed-top background_nav" role="navigation">
		<div class="container-fluid">
			<div class="navbar-header">
				<a class="navbar-brand" href="#"><span style="color: white;"><b>Fuzzy Cari Kendaraan | </b></span></a> <a href="master.php" class="navbar-brand" style="color: red;">Master Data</a>
			</div>
							
		</div><!-- /.container-fluid -->
	</nav>
	</div><!--/.sidebar-->
		
	<div class="col-sm-12">			
		
		<div class="row" >
			<div class="col-md-12">
			<div class="panel panel-default">
					<div>
						<img src="asset/background3.jpg" class="img img-responsive">
					</div>
				</div>
				<div class="panel panel-default">
					<div class="panel-heading"><svg class="glyph stroked desktop"><use xlink:href="#stroked-desktop"></use></svg>Hasil Berdasarkan Kriteria yang sudah dipilih ( operator = <?php echo $operator; ?> ) :</div>
					<div class="panel-body">
						<table class="table table-striped table-bordered table-hover" id="dataTables-example">
						    <thead>
						    <tr>
						        <th data-sortable="true">nama</th>
						        <th data-sortable="true">merek</th>
						        <th data-sortable="true">harga</th>
						        <th data-sortable="true">tahun</th>
						        <th data-sortable="true">bbm</th>
						        <th data-sortable="true">kapasitas</th>
						        <th data-sortable="true">engine</th>
						        <?php 
						        if($harga!='-'){
						        	echo "<th data-sortable='true'>".$harga."</th>";
						        }
						        if($jenis!='-'){
						        	echo "<th data-sortable='true'>".$jenis."</th>";
						        }
						        if($engine!='-'){
						        	echo "<th data-sortable='true'>".$engine."</th>";
						        }
						        if($kapasitas!='-'){
						        	echo "<th data-sortable='true'>".$kapasitas."</th>";
						        }
						        if($bbm!='-'){
						        	echo "<th data-sortable='true'>".$bbm."</th>";
						        }

						         ?>						        
						        <th data-sortable="true">Result</th>
						        <th data-sortable="true">Action</th>
						    </tr>
						    </thead>
						    <tbody>
						    		
						    		<?php foreach ($hasil as $isi) {
						    			?>
						    			<tr>
						    				<td><?php echo $isi['nama']; ?></td>
						    				<td><?php echo $isi['merek']; ?></td>
						    				<td><?php echo rp($isi['harga']); ?></td>
						    				<td><?php echo $isi['tahun']; ?></td>
						    				<td><?php echo $isi['bbm']; ?></td>
						    				<td><?php echo $isi['kp']; ?></td>
						    				<td><?php echo cc($isi['cc']); ?></td>
						    				<?php 
						    				if($harga!='-'){
									        	echo "<td data-sortable='true'>".$isi['nk_harga']."</td>";
									        }
									        if($jenis!='-'){
									        	echo "<td data-sortable='true'>".$isi['nk_jenis']."</td>";
									        }
									        if($engine!='-'){
									        	echo "<td data-sortable='true'>".$isi['nk_engine']."</td>";
									        }
									        if($kapasitas!='-'){
									        	echo "<td data-sortable='true'>".$isi['nk_kapasitas']."</td>";
									        }
									        if($bbm!='-'){
									        	echo "<td data-sortable='true'>".$isi['nk_bbm']."</td>";
									        }

									         ?>	
						    				<td><?php echo $isi['ks']; ?></td>
						    				<td><a href="detail.php?id=<?php echo $isi['id']; ?>" class="btn btn-primary" style="width: 100%;">Detail</a></td>
						    			</tr>

						    	<?php	} ?>					    	
						    </tbody>
						</table>
					</div>
				</div>
				
			</div>		
		</div>
		
								
		</div><!--/.row-->
	</div>	<!--/.main-->

	<script src="../js/jquery-1.11.1.min.js"></script>
	<script src="../js/bootstrap.min.js"></script>
	<script src="../js/chart.min.js"></script>
	<script src="../js/chart-data.js"></script>
	<script src="../js/easypiechart.js"></script>
	<script src="../js/easypiechart-data.js"></script>
	<script src="../js/bootstrap-datepicker.js"></script>
	<script src="../js/bootstrap-table.js"></script>

	<script src="../bower_components/datatables/media/js/jquery.dataTables.min.js"></script>
    <script src="../bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js"></script>

    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
               "language": {
            "lengthMenu": "Menampilkan _MENU_ baris tiap halaman",
            "zeroRecords": "Maaf, Data tidak ditemukan !",
            "info": "Halaman _PAGE_ dari _PAGES_",
            "infoEmpty": "Tidak ada data tersedia",
            "infoFiltered": "(difilter dari _MAX_ total data)"
        }

        });
    });
    </script>


	<script>
		!function ($) {
			$(document).on("click","ul.nav li.parent > a > span.icon", function(){		  
				$(this).find('em:first').toggleClass("glyphicon-minus");	  
			}); 
			$(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
		}(window.jQuery);

		$(window).on('resize', function () {
		  if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
		})
		$(window).on('resize', function () {
		  if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
		})

		function myFunction(master,group){
		  var cbarray = document.getElementsByName(group);
		  for(var i=0; i<cbarray.length; i++){
		   cbarray[i].checked = master.checked
		  }
		 }
	</script>	

</body>

</html>